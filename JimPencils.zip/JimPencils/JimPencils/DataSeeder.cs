﻿using JimPencils.Data.Model;

namespace JimPencils
{
    public static class DataSeeder
    {
        public static void Seed(this IHost host)
        {
            using var scope = host.Services.CreateScope();
            using var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
            context.Database.EnsureCreated();
            AddProducts(context);
        }

        private static void AddProducts(ApplicationDbContext context)
        {
            var products = context.Products.FirstOrDefault();
            if (products != null) { return ; }
            context.Products.Add(new Product
            {
                Name = "Pastels",
                Price = 100,
                Description = "Color Pastels",
                ImageUrl = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRayVBo18cpimCLSdcC6_Dz0S56AGZIifb7Kg&usqp=CAU",
                Buyers = new List<Buyer>
                {
                    new Buyer
                    {
                        Name="John"
                    },
                    new Buyer
                    {
                        Name = "Jill"
                    },
                    new Buyer
                    {
                        Name = "Jim"
                    }
                }
            });

            context.Products.Add(new Product
            {
                Name = "Writing Pencil",
                Price = 3,
                Description = "Writing Pencil",
                ImageUrl = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQnU-3Gc1PNg7h9Y3nKlF9ub0YuW9KoKpIPpw&usqp=CAU",
                Buyers = new List<Buyer>
                {
                    new Buyer
                    {
                        Name="John"
                    },
                    new Buyer
                    {
                        Name = "Jill"
                    }
                }
            });

            context.Products.Add(new Product
            {
                Name = "Pen Set",
                Price = 30,
                Description = "Pen Set",
                ImageUrl = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJ7ihOpx3DitT8ZtPgbEAWGPJ5KbseGcPSxw&usqp=CAU",
                Buyers = new List<Buyer>
                {
                    new Buyer
                    {
                        Name="John"
                    },
                    new Buyer
                    {
                        Name = "Jim"
                    }
                }
            });

            context.SaveChanges();
        }
    }
}
